package model;

import Service.ReservationService;

public class Tester {
    public static void main(String[] args){

          MainMenu menu = new MainMenu();
          menu.Mainmenu();

    }
}
